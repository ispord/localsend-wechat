use crate::http::client::scoped_host;
use std::borrow::Cow;

pub struct TargetUrl<'a> {
    pub version: ApiVersion,
    pub protocol: &'static str,
    pub host: String,
    pub port: u16,
    pub path: &'static str,

    /// Query parameters as raw key-value pairs; encoded when building the URL.
    pub params: &'a [(&'static str, &'a str)],
}

pub enum ApiVersion {
    V2,
    V3,
}

impl<'a> TargetUrl<'a> {
    pub fn to_string(&self) -> String {
        let base = format!(
            "{}://{}:{}/api/localsend/{}{}",
            self.protocol,
            // A scoped IPv6 address (`fe80::1%3`) cannot be represented in a
            // URL and becomes a synthetic host name instead.
            match scoped_host::encode(&self.host) {
                Some(encoded) => Cow::Owned(encoded),
                None => match self.host.contains(':') {
                    true => Cow::Owned(format!("[{}]", self.host)), // IPv6 addresses need to be enclosed in brackets
                    false => Cow::Borrowed(&self.host),
                },
            },
            self.port,
            match self.version {
                ApiVersion::V2 => "v2",
                ApiVersion::V3 => "v3",
            },
            self.path
        );
        if self.params.is_empty() {
            base
        } else {
            let query = form_urlencoded::Serializer::new(String::new())
                .extend_pairs(self.params.iter().copied())
                .finish();
            format!("{}?{}", base, query)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::{ApiVersion, TargetUrl};

    #[test]
    fn test_pin_survives_query_round_trip() {
        for pin in ["1234", "a+b", "a&b", "a#b", "%41", "a b", "קוד", ""] {
            let url = TargetUrl {
                version: ApiVersion::V2,
                protocol: "https",
                host: "192.168.1.1".to_string(),
                port: 53317,
                path: "/prepare-download",
                params: &[("pin", pin), ("sessionId", "session-1")],
            }
            .to_string();
            let url = reqwest::Url::parse(&url).unwrap();
            let params: Vec<_> = form_urlencoded::parse(url.query().unwrap().as_bytes())
                .into_owned()
                .collect();
            assert_eq!(
                params,
                vec![
                    ("pin".to_string(), pin.to_string()),
                    ("sessionId".to_string(), "session-1".to_string())
                ],
                "PIN: {pin:?}"
            );
        }
    }

    #[test]
    fn test_build_url_ipv4() {
        let url = TargetUrl {
            version: ApiVersion::V2,
            protocol: "https",
            host: "192.168.1.1".to_string(),
            port: 53317,
            path: "/register",
            params: &[],
        }
        .to_string();
        assert_eq!(url, "https://192.168.1.1:53317/api/localsend/v2/register");
    }

    #[test]
    fn test_build_url_ipv6() {
        let url = TargetUrl {
            version: ApiVersion::V2,
            protocol: "https",
            host: "::1".to_string(),
            port: 53317,
            path: "/register",
            params: &[],
        }
        .to_string();
        assert_eq!(url, "https://[::1]:53317/api/localsend/v2/register");
    }

    #[test]
    fn test_build_url_scoped_ipv6() {
        let url = TargetUrl {
            version: ApiVersion::V2,
            protocol: "https",
            host: "fe80::1%3".to_string(),
            port: 53317,
            path: "/register",
            params: &[],
        }
        .to_string();
        assert_eq!(
            url,
            "https://fe80--1s3.scoped.localsend.internal:53317/api/localsend/v2/register"
        );
    }

    #[test]
    fn test_build_url_http() {
        let url = TargetUrl {
            version: ApiVersion::V2,
            protocol: "http",
            host: "192.168.1.1".to_string(),
            port: 53317,
            path: "/info",
            params: &[],
        }
        .to_string();
        assert_eq!(url, "http://192.168.1.1:53317/api/localsend/v2/info");
    }
}
